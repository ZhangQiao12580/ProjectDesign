package client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JTextField;

import util.FindLocalIp;
import util.JsonTools;
import util.Request;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Map;
import java.awt.event.ActionEvent;

public class LoginForm{

	private JFrame frmLogin;
	private JTextField textField;
	private final static String SEVER="192.168.43.17";

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm window = new LoginForm();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public LoginForm() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setTitle("Login");
		frmLogin.setAlwaysOnTop(true);
		frmLogin.setBounds(100, 100, 190, 170);
		frmLogin.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("用户名");
		lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 16));
		lblNewLabel.setBounds(59, 10, 48, 23);
		frmLogin.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(33, 54, 113, 21);
		frmLogin.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("提交");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt=textField.getText();
				if(!txt.contentEquals(""))
				{
					Map<String, String> head=JsonTools.getReqHead();
					head.put("type", JsonTools.LOGIN);
					Map<String,String> login=JsonTools.getLogin();
					try {
						login.put("ip", FindLocalIp.getLocalIp());
					} catch (UnknownHostException e1) {
						e1.printStackTrace();
					}
					login.put("username", txt);
					String value=JsonTools.getJson(login);
					head.put("value", value);
					try {
						Request.postRequest(SEVER, JsonTools.getJson(head));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				//System.exit(0);
				frmLogin.dispose();
			}
		});
		btnNewButton.setBounds(43, 95, 93, 23);
		frmLogin.getContentPane().add(btnNewButton);
		frmLogin.setVisible(true);
	}
}
