package client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.JTextArea;

import util.FindLocalIp;
import util.JsonTools;
import util.Request;
import util.Response;
import util.StringUtil;
import util.XMLUtil;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ItemEvent;

public class MainForm {

	private JFrame frmLiberateandskyV;
	private final static String SEVER="192.168.43.17";	//Ĭ�Ϸ�����ipΪ192.168.10.1
	private JTextField input;
	
	private static JTextArea chatbox = new JTextArea(" ");
	private static JLabel jLabel=new JLabel();
	private static JComboBox comboBox = new JComboBox();

	/**
	 * Launch the application.
	 * @throws IOException 
	 * @throws UnknownHostException 
	 */
	public static void main(String[] args) throws UnknownHostException, IOException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//测试服务器连接状态
					/*Map<String, String> test=JsonTools.getReqHead();
					test.put("type",JsonTools.TEST);
					Request.postRequest(SEVER, JsonTools.getJson(test));
					try {
						String test_res=Response.getRepsValue();
						if(test_res.equals(""))
						{
							new MesgForm("与服务器连接失败！");
						}
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					*/
					
					/*
					Map<String, String> valid=JsonTools.getReqHead();
					valid.put("type",JsonTools.VALID);
					Request.postRequest(SEVER, JsonTools.getJson(valid));
					try {
						String valid_res=Response.getRepsValue();
						if(valid_res.equals("false"))
						{
							new MesgForm("与服务器连接失败！");
						}else {
							
						}
					} catch (Exception e1) {
						e1.printStackTrace();
					}*/
					
					/*Map<String, String> valid=JsonTools.getReqHead();
					valid.put("type",JsonTools.VALID);
					valid.put("value",FindLocalIp.getLocalIp());
					Request.postRequest(SEVER, JsonTools.getJson(valid));*/
					
					/*MainForm window = new MainForm();
					window.frmLiberateandskyV.setVisible(true);*/
					
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		new MesgForm(SEVER);
		
		//new LoginForm();
		
		Map<String, String> valid=JsonTools.getReqHead();
		valid.put("type",JsonTools.VALID);
		valid.put("value", FindLocalIp.getLocalIp());
		Request.postRequest(SEVER, JsonTools.getJson(valid));
		
		new MainForm();
		
		//启动客户端监听线程
		try {
			ServerSocket serverSocket=new ServerSocket(12580);
			Socket socket=null;
			while(true)
			{
				socket=serverSocket.accept();
				if(socket!=null)
				{
					ClientThread clientThread=new ClientThread(socket, chatbox, comboBox, jLabel);
					clientThread.run();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			new ErrorForm();
			e.printStackTrace();
		}
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 * @throws UnknownHostException 
	 */
	public MainForm() throws UnknownHostException, IOException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 * @throws UnknownHostException 
	 */
	private void initialize() throws UnknownHostException, IOException {
		frmLiberateandskyV = new JFrame();
		frmLiberateandskyV.setTitle("LiberateAndSky V1.0");
		frmLiberateandskyV.setBounds(100, 100, 392, 420);
		frmLiberateandskyV.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLiberateandskyV.getContentPane().setLayout(null);
		frmLiberateandskyV.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
			{
				try {
					Map<String, String> valid=JsonTools.getReqHead();
					valid.put("type",JsonTools.OFFLINE);
					valid.put("value", FindLocalIp.getLocalIp());
					Request.postRequest(SEVER, JsonTools.getJson(valid));
				} catch (Exception e1) {
					new ErrorForm();
					e1.printStackTrace();
				}
			}
		}});
		
		JLabel label = new JLabel("当前用户:");
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setBounds(10, 25, 112, 15);
		frmLiberateandskyV.getContentPane().add(label);
		
		//JComboBox comboBox = new JComboBox();
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				//如果监听到的状态改变是选中事件而不是离开事件
				/*if(e.getStateChange()==ItemEvent.SELECTED)
				{
					try {
					String item=comboBox.getSelectedItem().toString();
					System.out.println(item);
					Map<String, String> head=JsonTools.getReqHead();
					head.put("type", JsonTools.ISONLINE);	//发送的isonline的参数为当前主机的ip
					head.put("value", FindLocalIp.getLocalIp());
					if(Request.postRequest(StringUtil.spliteUserIp(item), JsonTools.getJson(head))==1)
					{
						chatbox.setText("");
					}	
					} catch(Exception e1) {
						new ErrorForm();
						e1.printStackTrace();
					}
				}*/
			}
		});
		comboBox.setBounds(80, 23, 80, 21);
		
		jLabel.setBounds(250, 23, 150, 21);
		jLabel.setText("欢迎你:");
		jLabel.setVisible(true);
		frmLiberateandskyV.getContentPane().add(jLabel);
		
		Map<String, String> map=JsonTools.getReqHead();
		map.put("type",JsonTools.REQUSERLIST);
		Request.postRequest(SEVER, JsonTools.getJson(map));

		/*Map<String, String> map=JsonTools.getReqHead();
		map.put("type",JsonTools.REQUSERLIST);
		Request.postRequest(SEVER, JsonTools.getJson(map));
		//������Ӧ�߳�
		List<String> userlist=StringUtil.splitStr(Response.getRepsValue());
		for(String str:userlist)
		{
			comboBox.addItem(str);
		}*/
		frmLiberateandskyV.getContentPane().add(comboBox);
		
		chatbox.setBackground(SystemColor.controlHighlight);
		chatbox.setEditable(false);
		chatbox.setBounds(10, 50, 355, 260);
		frmLiberateandskyV.getContentPane().add(chatbox);
		
		JButton btnNewButton = new JButton("\u53D1\u9001");
		//点击发送按钮的事件
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String chatarea=chatbox.getText();
				String txt=input.getText();
				String dest=comboBox.getSelectedItem().toString();
				if(!txt.equals(""))
				{
					Map<String, String> head=JsonTools.getReqHead();
					head.put("type", JsonTools.CHAT);
					Map<String, String> mesg=JsonTools.getChatMesg();
					try {
						String localip=FindLocalIp.getLocalIp();
						String username=jLabel.getText();
						username=username.substring(4,username.length());
						mesg.put("from",username+"("+localip+")");
					} catch (UnknownHostException e1) {
						new ErrorForm();
						e1.printStackTrace();
					}
					mesg.put("dest",dest);
					mesg.put("content", txt);
					mesg.put("time", StringUtil.getNowTime());
					head.put("value", JsonTools.getJson(mesg));
					String json=JsonTools.getJson(head);
					try {
						if(Request.postRequest(StringUtil.spliteUserIp(dest), json)==1)
						{
							chatarea+="我 "+StringUtil.getNowTime();
							chatarea+="\n";
							chatarea+=txt+"\n";
							chatarea+=StringUtil.getLine()+"\n";
							chatbox.setText(chatarea);
						}
					} catch (Exception e1) {
						new ErrorForm();
						e1.printStackTrace();
					} 
				}
			}
		});
		btnNewButton.setBounds(305, 337, 60, 23);
		frmLiberateandskyV.getContentPane().add(btnNewButton);
		
		input = new JTextField();
		input.setBounds(10, 338, 275, 25);
		frmLiberateandskyV.getContentPane().add(input);
		input.setColumns(10);
		
		JButton fresh = new JButton("刷新");
		//点击发送按钮的事件
		fresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Map<String, String> map=JsonTools.getReqHead();
				map.put("type",JsonTools.REQUSERLIST);
				try {
					Request.postRequest(SEVER, JsonTools.getJson(map));
				} catch (Exception e1) {
					new ErrorForm();
					e1.printStackTrace();
				}
			}
		});
		fresh.setBounds(180, 23, 60, 23);
		frmLiberateandskyV.getContentPane().add(fresh);
		
		
		frmLiberateandskyV.setVisible(true);
	}
}
