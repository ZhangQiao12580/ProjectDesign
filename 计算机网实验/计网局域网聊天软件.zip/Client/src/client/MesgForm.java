package client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JButton;

import util.JsonTools;
import util.Request;
import util.Response;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Map;

public class MesgForm  extends JFrame{

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MesgForm window = new MesgForm("123");
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public MesgForm(String mesg) {
		initialize(mesg);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String mesg) {
		frame = new JFrame();
		frame.setBounds(100, 100, 190, 170);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel();
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 14));
		lblNewLabel.setBounds(20, 24, 131, 51);
		lblNewLabel.setText("Loading...");
		frame.getContentPane().add(lblNewLabel);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		button.setBounds(40, 85, 93, 23);
		button.setVisible(false);
		frame.getContentPane().add(button);
		frame.setVisible(true);
		
		Map<String, String> test=JsonTools.getReqHead();
		test.put("type",JsonTools.TEST);
		try {
			//if(Request.postRequest(mesg, JsonTools.getJson(test))==1)
			Request.postRequest(mesg, JsonTools.getJson(test));
				String res=Response.getRepsValue();
				System.out.println(res);
				if(res.equals("")==false)
				{
					//服务器连接成功
					frame.dispose();
				}
		} catch (Exception e1) {
			//System.out.println(e1.getMessage());
			e1.printStackTrace();
			lblNewLabel.setText("服务器连接失败!");
			button.setVisible(true);
		}
	}

}
