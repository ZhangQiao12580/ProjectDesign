package client;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import javafx.collections.ListChangeListener.Change;
import util.FindLocalIp;
import util.JsonTools;
import util.StringUtil;

public class ClientThread implements Runnable{

	private JTextArea jtextArea;
	private JComboBox jComboBox;
	private JLabel jLabel;
	private Socket socket;
	
	public ClientThread(Socket socket,JTextArea textarea,JComboBox jcombobox,JLabel jlabel) {
		this.jComboBox=jcombobox;
		this.jtextArea=textarea;
		this.jLabel=jlabel;
		this.socket=socket;
	}
	
	public ClientThread(JTextArea jtextArea) {
		this.jtextArea=jtextArea;
	}
	
	public void run(){
		String rec="";
		try {
			InputStream in = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(in, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			rec=br.readLine();
		} catch (Exception e) {
			new ErrorForm();
			e.printStackTrace();
		}
		System.out.println(rec);
		Map<String, String> head=JsonTools.getMap(rec);
		String type=head.get("type");
		String value=head.get("value");
		String ip="";
		try {
			ip=String.valueOf(socket.getInetAddress().getHostAddress());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			new ErrorForm();
			e.printStackTrace();
		}
		
		if(type.equals(JsonTools.LOGIN+"_r"))
		{
			
			jLabel.setText(jLabel.getText()+value);
		}
		else if(type.equals(JsonTools.ISONLINE))
		{
			//jtextArea.setText("对方在线，赶快找他聊天吧！\n"+StringUtil.getLine()+"\n");
		}
		else if(type.equals(JsonTools.REQUSERLIST+"_r"))
		{
			List<String> userlist=StringUtil.splitStr(value);
			jComboBox.removeAllItems();
			for(String str:userlist)
			{
				jComboBox.addItem(str);
			}
		}
		else if(type.equals(JsonTools.VALID+"_r"))
		{
			if(value.equals("false"))
			{
				//弹出注册窗口
				new LoginForm();
			}else
			{
				System.out.println(jLabel.getText());
				jLabel.setText(jLabel.getText()+value);
			}
		}
		else if(type.equals(JsonTools.CHAT))
		{
			//TODO
			Map<String,String> conetnt=JsonTools.getMap(value);
			String from=conetnt.get("from");
			String dest=conetnt.get("dest");
			String mesg=conetnt.get("content");
			String time=conetnt.get("time");
			try {
				System.out.println(dest+" "+FindLocalIp.getLocalIp());
				if(dest.contains(FindLocalIp.getLocalIp()))
				{
					String selecteditemvalue=jComboBox.getSelectedItem().toString();
					if(!selecteditemvalue.equals(from))
					{
						jComboBox.setSelectedItem(from);
						jtextArea.setText("");
					}
					from=StringUtil.spliteUsername(from);
					String chatarea=jtextArea.getText();
					chatarea+=from+" "+time+"\n";
					chatarea+=mesg+"\n";
					chatarea+=StringUtil.getLine()+"\n";
					jtextArea.setText(chatarea);
				}
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				new ErrorForm();
				e.printStackTrace();
			}
		}
	}

	
}
