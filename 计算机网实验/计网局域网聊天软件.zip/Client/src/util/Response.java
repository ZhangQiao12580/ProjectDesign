package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Response {
	/*
	 * ���߳���Ӧ����
	 * */
	
	public static String getRepsValue() throws IOException{
		ServerSocket serverSocket=new ServerSocket(12580);
		Socket socket=null;
		String str="";
		try{
			socket = serverSocket.accept();
			InputStream in = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(in, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			//System.out.println("�ͻ���˵��" + br.readLine());
			//���϶�ȡ�ͻ�������
			//System.out.println("�ͻ���˵��" + br.readLine());
			str=br.readLine();
		}catch(Exception e){

			e.printStackTrace();
			return "";
		}finally {
			serverSocket.close();
			if(socket!=null)
			{
				socket.close();
			}
		}
		return str;
	}
}
