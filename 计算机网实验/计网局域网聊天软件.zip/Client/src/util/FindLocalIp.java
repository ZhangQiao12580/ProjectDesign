package util;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public class FindLocalIp {
	
		public static List<String> getIpList() {
			
			List<String> list=new ArrayList<String>();
			try {
				//Runtime.getRuntime().exec("ping 192.168.1.1").destroy();
				//Runtime.getRuntime().exec("for /l %i in (1,1,255) do " +
				//		"(ping -w 2 -n 1 192.168.1.%i)").destroy();
				
				String localIP=InetAddress.getLocalHost().getHostAddress();
				String[] net=localIP.split("\\.");
				
				int j=Integer.parseInt(net[2]);
				for(int i=1;i<256;i++){
					Runtime.getRuntime().exec("ping -w 2 -n 1 192.168."+j+"."+i).destroy();
				}
				
				Process p=Runtime.getRuntime().exec("arp -a");
				BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
				
				br.readLine();
				br.readLine();
				br.readLine();
				String temp=null;
				while(((temp=br.readLine())!=null&&!temp.isEmpty())){
					//System.out.println(temp.trim().split(" ")[0]);
					String string=temp.trim().split(" ")[0];
					if(string.contains("10.0."))
					{
						list.add(string);
					}
					//list.add(string);
				}
				
				//String localIP=InetAddress.getLocalHost().getHostAddress();
				//String[] net=localIP.split("\\.");
				
				//System.out.println(net[2]);
				
				//System.out.println(InetAddress.getLocalHost().getHostAddress());
				p.destroy();
				br.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
			
		}
		
		public static String getLocalIp() throws UnknownHostException
		{
			String str=String.valueOf(InetAddress.getLocalHost());
			int index=str.indexOf("/");
			str=str.substring(index+1, str.length());
			return str;
		}
		
/*		public static void main(String[] args) throws UnknownHostException {
			System.out.println(getLocalIp());
			
		}*/

}
