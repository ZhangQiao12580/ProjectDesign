package util;



import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;


public class JsonTools {
	/*
	 * {key,value}
	 * valid username?false
	 * login {ip,username}
	 * chat {from,dest,content,time}
	 * requserlist null
	 * isonline dest
	 * offline
	 * */
	public final static String VALID="valid"; 
	public final static String LOGIN ="login";
	public final static String CHAT ="chat";
	public final static String REQUSERLIST="requserlist";
	public final static String TEST="test";
	public final static String ISONLINE="isonline";
	public final static String OFFLINE="offline";
	
	public static Map<String, String> getReqHead()
	{
		Map<String, String> head=new HashMap<String, String>();
		head.put("type","");
		head.put("value", "");
		return head;
	}
	
	public static Map<String,String> getChatMesg()
	{
		Map<String, String> chatmesg=new HashMap<String, String>();
		chatmesg.put("from", "");
		chatmesg.put("dest", "");
		chatmesg.put("time","");
		chatmesg.put("content", "");
		return chatmesg;
	}
	
	public static Map<String,String> getLogin()
	{
		Map<String, String> user=new HashMap<String, String>();
		user.put("ip", "");
		user.put("username", "");
		return user;
	}
	
	public static String getJson(Object object)
	{
		return JSON.toJSONString(object);
	}
	
	public static Map<String, String> getMap(String json)
	{
		Map<String, String> map=JSON.parseObject(json,Map.class);
		return map;
	}
}
