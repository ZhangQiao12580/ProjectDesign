package util;

import java.io.File;
import java.io.IOException;

public class GetXMLPath {
	public  String getPath()
	{
		//String path = this.getClass().getResource("/").getPath();
		File file=new File("");
		try {
			return file.getCanonicalPath()+"/src/userlist.xml";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//return path.substring(1, path.length());
		return "";
	}
	
	/*public static void main(String[] args) {
		GetXMLPath getXMLPath=new GetXMLPath();
		System.out.println(getXMLPath.getPath());
	}*/
}
