package util;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Request {
	
	public static int postRequest(String aimip,String reqmesg) throws UnknownHostException, IOException
	{
		Socket socket=new Socket(aimip, 12580);
		try{
			OutputStream out = socket.getOutputStream();
			//OutputStreamWriter osw = new OutputStreamWriter(out, true);
			OutputStreamWriter osw = new OutputStreamWriter(out, "UTF-8");
			PrintWriter pw = new PrintWriter(osw, true);
			//pw.println("��ã���������");
			//����Scanner��ȡ�û���������
			pw.write(reqmesg);
			pw.close();
			osw.close();
			out.close();
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(socket != null){
				try{
					
					socket.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		return 1;
	}
	
	/*public static void main(String[] args) {
		try {
			postRequest("192.168.43.17", "123");
			System.out.println("发送成功");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
}
