package util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.SimpleFormatter;

public class StringUtil {
	public static List<String> splitStr(String ordstr)
	{
		List<String> list=new ArrayList<String>();
		String []arrs=ordstr.split("-");
		for(String str:arrs)
		{
			list.add(str);
		}
		return list;
	}
	
	public static String getLine()
	{
		return "-----------------------------------------------------";
	}
	
	public static String getNowTime()
	{
		Date date=new  Date();
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return simpleDateFormat.format(date);
	}
	
	public static String spliteUsername(String user)
	{
		int index=user.indexOf("(");
		return user.substring(0, index);
	}
	
	public static String spliteUserIp(String user)
	{
		int index=user.indexOf("(");
		int rightindex=user.indexOf(")");
		System.out.println(user);
		return user.substring(index+1, rightindex);
	}
}
