package sever;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Map;

import com.sun.xml.internal.ws.util.xml.XmlUtil;

import util.JsonTools;
import util.Request;
import util.XMLUtil;

/*服务器监听线程
 * */
public class RespThread implements Runnable{

	Socket socket=null;
	
	public RespThread(Socket socket)
	{
		this.socket=socket;
	}
	
	public void run() {
		String rec="";
		try {
			InputStream in = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(in, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			rec=br.readLine();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(rec);
		Map<String, String> head=JsonTools.getMap(rec);
		String type=head.get("type");
		String value=head.get("value");
		String ip="";
		try {
			ip=String.valueOf(socket.getInetAddress().getHostAddress());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int index=ip.indexOf("/");
		ip=ip.substring(index+1, ip.length());
		try {
			if(type.equals(JsonTools.TEST))
			{
				Request.postRequest(ip, "true");
			}
			else if(type.equals(JsonTools.LOGIN))
			{
				Map<String, String> map=JsonTools.getMap(value);
				String userip=map.get("ip");
				String username=map.get("username");
				//插入到用户列表中XML中
				XMLUtil.insertUser(ip, username);
				String userlist=OnLIneStatistic.userlist;
				if(!userlist.contains(username))
				{
					OnLIneStatistic.userlist+=username+"("+ip+")-";
				}
				Map<String, String> resp=JsonTools.getReqHead();
				resp.put("type", JsonTools.LOGIN+"_r");
				resp.put("value", username);
				Request.postRequest(ip, JsonTools.getJson(resp));
			}
			else if(type.equals(JsonTools.REQUSERLIST))
			{
				Map<String, String> resp=JsonTools.getReqHead();
				resp.put("type", JsonTools.REQUSERLIST+"_r");
				//resp.put("value",XMLUtil.getUserList());
				String list=OnLIneStatistic.userlist;
				list=list.substring(0, list.length()-1);
				resp.put("value",list);
				Request.postRequest(ip, JsonTools.getJson(resp));
			}
			else if(type.equals(JsonTools.VALID))
			{
				Map<String, String> resp=JsonTools.getReqHead();
				resp.put("type", JsonTools.VALID+"_r");
				String str=XMLUtil.isValid(ip);
				String userlist=OnLIneStatistic.userlist;
				if(!str.equals("false")&&!userlist.contains(str))
				{
					OnLIneStatistic.userlist+=str+"("+ip+")-";
				}
				resp.put("value", str);
				Request.postRequest(ip, JsonTools.getJson(resp));
			}
			else if(type.equals(JsonTools.OFFLINE))
			{
				String str=XMLUtil.isValid(ip);
				str=str+"("+ip+")-";
				String userlist=OnLIneStatistic.userlist;
				System.out.println("========"+userlist+" "+str);
				if(userlist.contains(str))
				{
					userlist=userlist.replace(str, "");
				}
				OnLIneStatistic.userlist=userlist;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	public static void main(String[] args) throws IOException {
		System.out.println("服务器启动中...");
		ServerSocket serverSocket=null;
		Socket socket=null;
		try {
			serverSocket=new ServerSocket(12580);
		} catch (Exception e) {
			System.out.println("服务器启动失败!");
			e.printStackTrace();
			return;
		}
		System.out.println("服务器启动完成!");
		while(true)
		{
			socket=serverSocket.accept();
			if(socket!=null)
			{
				RespThread respThread=new RespThread(socket);
				respThread.run();
			}
		}
	}
}
