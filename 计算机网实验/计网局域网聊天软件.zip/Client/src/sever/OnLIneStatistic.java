package sever;

public class OnLIneStatistic {
	public static String userlist="";
}
