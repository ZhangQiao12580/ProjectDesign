﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Program
    { 
        static void Main(string[] args)
        {
            List<int> list = GetYuanGen(7);
            foreach(int i in list)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }

        static List<int> GetYuanGen(int n)
        {
            List<int> res = new List<int>();

            for (int i = 2; i <= n - 1; i++)
            {
                if (Math.Pow(i, n - 1) % n != 1)
                {
                    continue;
                }
                List<int> t = new List<int>();
                bool flag = false;
                for (int j = 2; j <= n - 1; j++)
                {
                    if (j == i)
                    {
                        continue;
                    }
                    int x = Convert.ToInt32(Math.Pow(i, j) % n);
                    if (t.Contains(x))
                    {
                        flag = true;
                        break;
                    }
                    t.Add(x);
                }
                if (!flag)
                {
                    res.Add(i);
                }
            }

            return res;
        }
    }
}
