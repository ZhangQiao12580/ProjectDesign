package des;

public class ChildPWD {
	
	//密钥
	public static int MIYAO [] = {0,0,1,1,0,0,0,1,0,0,1,1,0,0,1,0,0,0,1,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,1,1,0,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,1,0,0,1,1,1,0,0,0};

	//迭代次数
	public static int IteratorNum [] ={1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1};
	
	public static int C [] = {57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36};
	
	public static int D [] = {63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4};

	//置换2
	public static int ZhiHuan2 [] ={14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32};
	
	public static int [] GetChildPWD(int order)
	{
		int demoArray[] = new int[48];
		int C[] = new int [28];
		int D[] = new int [28];
		int i=0;
		
		for(int j=0;j<28;j++)
		{
			
			C[j]=ChildPWD.MIYAO[ChildPWD.C[j]-1];
		}
		for(int j=0;j<28;j++)
		{
			D[j]=ChildPWD.MIYAO[ChildPWD.D[j]-1];
		}
		
		
		
		for(i=0;i<order;i++)
		{
			C = LeftMove(C, IteratorNum[i]);
			D = LeftMove(D, IteratorNum[i]);
		}
		
		for(i=0;i<48;i++)
		{
			int count = ZhiHuan2[i];
			if(count<=28)
			{
				demoArray[i]=C[count-1];
			}
			else
			{
				demoArray[i]=D[count-29];
			}
		}
		
		return demoArray;
	}
	
	private static int [] LeftMove(int arrs[],int count)
	{
		for(int i=0;i<count;i++)
		{
			int first = arrs[0];
			for(int j=1;j<arrs.length;j++)
			{
				arrs[j-1]=arrs[j];
			}
			arrs[arrs.length-1]=first;
		}
		return arrs;
	}
	
	public static void showarr(int arr[])
	{
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]);
			if((i+1)%8==0)
			{
				System.out.print(" ");
			}
		}
		System.out.println("");
	}
	
	public static void main(String[] args) {
		for (int i = 1; i <=16; i++) {
			showarr(GetChildPWD(i));
		}
	}
}
